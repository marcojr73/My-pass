<?php

namespace App\Http\Controllers;

use http\Env\Response;
use Illuminate\Contracts\Foundation\Application;
use Illuminate\Contracts\Routing\ResponseFactory;
use Illuminate\Http\Request;

class AuthController extends Controller
{
    public function signUp(Request $request)
    {
        $jsonData = $request->json()->all();

        if (isset($jsonData['userName'])) {
            $userName = $jsonData['userName'];
            return response($userName, 200);
        } else {
            return response($jsonData, 200);
        }
    }
}
